package com.example.demo;

public class ArbitrageSystem {
	static String name;
	public void nameOfUser(String uname)
	{
		name=uname;
	}
	
}
