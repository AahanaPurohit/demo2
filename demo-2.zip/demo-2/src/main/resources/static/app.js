var app = angular.module('postserviceApp', [ 'ngRoute' ]);


app.config(function($routeProvider) {
	$routeProvider

	.when('/', {
		templateUrl : 'login.html',
		controller: 'loginCtrl'
	})
	.when('/home', {
		templateUrl : 'home.html',
		controller: 'homeCtrl'
	})
	
	.otherwise({ redirectTo: '/' });
	
	
});

app.controller('loginCtrl', function($scope){
	$scope.message = "Hello, this is login";
});
app.controller('homeCtrl', function($scope, $http, $location){
	$scope.message = "Hello, this is home";

	   
});




app.controller('postserviceCtrl', function($scope, $http, $location) {
	$scope.name = null;
	$scope.password = null;
	$scope.lblMsg = null;
	
	$scope.postdata = function(username, password) {
		var data = {
			username : username,
			password : password
		};

		$http.post('/connect', JSON.stringify(data)).then(
				function(response) {
					if (response.data) {
						$scope.msg = "Post Data Submitted Successfully!";
						window.location.replace("http://localhost:8082/home.html")
						
						$scope.name = null;
						$scope.password = null;
						$scope.lblMsg = null;
						$scope.msg = "Welcome Mr."+$scope.username;
					} else {
						$scope.msg = "Invalid User";
						$location.path('/')
					}
				}, function(response) {
					$scope.msg = "Unsuccessful";
					$scope.statusval = response.status;
					$scope.statustext = response.statusText;
					$scope.headers = response.headers();
				});
	};
	
});




